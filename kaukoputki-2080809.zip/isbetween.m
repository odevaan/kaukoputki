function b=isbetween(t1,t2,t3)
  b=(t1<t2 & t2<t3);
