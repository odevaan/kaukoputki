%disp('Reaaliaikainen k�ytt�liittym�: anna komento "kaukoputki"');
%disp('Ei-reaaliaikainen k�ytt�liittym�: anna komento "gui"');
kaukoputki
