nanomex MEX funktio Matlabiin NANO-B:n ohjausta varten.
Toimii ainakin Matlabin versioissa 5.3
On k�ytetty menestyksekk��sti Jakokosken kaukoputken ohjaamiseen
Matlabista k�sin.

Ohjelmoitu joskus Herran vuonna 2000.

Pertti P��kk�nen
15.2.2003
