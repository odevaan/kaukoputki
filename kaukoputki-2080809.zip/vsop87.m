global vsopvar vsopind;
load vsop87.mat;